package edu.birzeit.restapplication;

public class Car {
    private int ID;
    private String type;

    public int getID() {
        return ID;
    }
    public void setID(int ID) {
        this.ID = ID;
    }
    public String getType() {
        return type;
    }
    public void setType(String name) {
        this.type = name;
    }
    @Override
    public String toString() {
        return "Student{" +
                "\nID= " + ID +
                "\ntype= " + type +
                +'\n'+'}'+'\n';
    }
}
