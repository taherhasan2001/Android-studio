package edu.birzeit.restapplication;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import java.util.List;
public class MainActivity extends AppCompatActivity {
    Button button;
    LinearLayout linearLayout;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setProgress(false);
        button = (Button) findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ConnectionAsyncTask connectionAsyncTask = new ConnectionAsyncTask(MainActivity.this);//

                connectionAsyncTask.execute("https://658582eb022766bcb8c8c86e.mockapi.io/api/mock/rest-apis/encs5150/car-types");
            }
        });
        linearLayout = (LinearLayout) findViewById(R.id.layout);
    }
    public void setButtonText(String text) {
        button.setText(text);
    }
    public void fillStudents(List<Car> cars) {
        
         LinearLayout linearLayout = (LinearLayout)
                 findViewById(R.id.layout);
         linearLayout.removeAllViews();
         for (int i = 0; i < cars.size(); i++) {
             TextView textView = new TextView(this);
             String text =
                     "id = "  +String.valueOf(cars.get(i).getID()) +
                             "\ntype =  " + cars.get(i).getType() +
                             "\n---------------------------------\n";
             textView.setText(text);
             linearLayout.addView(textView);
         }
    }
    public void setProgress(boolean progress) {
        ProgressBar progressBar = (ProgressBar)
                findViewById(R.id.progressBar);
        if (progress) {
            progressBar.setVisibility(View.VISIBLE);
        } else {
            progressBar.setVisibility(View.GONE);
        }
    }

    public void raiseError(){
        LinearLayout linearLayout = (LinearLayout)
                findViewById(R.id.layout);
        linearLayout.removeAllViews();
        TextView textView = new TextView(this);
        String text = "ERROR" ;
        textView.setText(text);
        linearLayout.addView(textView);
    }
}
